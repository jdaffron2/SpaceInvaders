//Taylor Heatherly

package program7;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonBounce extends JFrame
{
  private JPanel PaintPanel = new JPanel(new BorderLayout());
  private JPanel ButtonPanel = new JPanel(new FlowLayout());
  private JPanel SliderPanel = new JPanel(new GridLayout(5, 1, 0, 10));
  private JButton[] button = new JButton[2];
  private ButtonGroup bg = new ButtonGroup();
  private Font font = new Font("Serif", Font.BOLD, 12);
  private JScrollBar jsb[] = new JScrollBar[5];
  private JLabel jl[] = new JLabel[5];
  private String[] button_name = {"Start", "Stop"};
  private String[] scroll_name = {"X Increment: ", "Y Increment: ", "X size: ", "Y size: ", "Speed: "};
  private int[] initial = {10, 10, 15, 15, 90};
  private int[] max = {10, 10, 99, 99, 90};
  private int x_pos;
  private int y_pos;
  private int x_inc = initial[0];
  private int y_inc = initial[1];
  private int x_size = initial[2];
  private int y_size = initial[3];
  private int speed = initial[4];
  private boolean flag = false;
  private Dimension bounds;
  private BallPanel bp;

  public ButtonBounce()
  {
    super("Button Bounce");

    this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);

    Container cp = this.getContentPane();
    PaintPanel.setSize(550, 415);
    bounds = new Dimension(PaintPanel.getSize());
    bp = this.new BallPanel();
    PaintPanel.add(bp);

    //Set the ScrollBars
    for (int i = 0; i < 4; i++)
    {
      JPanel jp = new JPanel(new GridLayout(3, 0, 0, 4));
      jsb[i] = new JScrollBar(JScrollBar.HORIZONTAL, initial[i], 0, 0, max[i]);
      jsb[i].setName("sb" + i);
      jsb[i].addAdjustmentListener(new AdjustmentHandler());
      jl[i] = new JLabel(scroll_name[i] + jsb[i].getValue());
      //JLabel label = new JLabel("               ");
      //jp.add(label);
      jp.add(jsb[i]);
      jp.add(jl[i]);
      SliderPanel.add(jp);
    }

    //Set the Buttons
    for (int i = 0; i < 2; i++)
    {
      JPanel jp1 = new JPanel();
      button[i] = new JButton(button_name[i]);
      button[i].setFont(font);
      button[i].addActionListener(new ActionHandler());
      bg.add(button[i]);
      jp1.add(button[i]);
      ButtonPanel.add(jp1);
    }

    //Add it all to the window
    this.setResizable(false);
    cp.add(PaintPanel, BorderLayout.CENTER);
    cp.add(SliderPanel, BorderLayout.EAST);
    cp.add(ButtonPanel, BorderLayout.SOUTH);
    this.setSize(650, 500);
    this.setVisible(true);
    
    //Game Loop
    while(flag==false)
    { 
    	try
        {
          Thread.sleep(100 - speed);
        }
        catch (InterruptedException ie)
        {
          ie.printStackTrace();
        }
    	while (flag==true)
    	ballMovement();
      
    }
  }

  //For the Buttons
  class ActionHandler implements ActionListener
  {
    public void actionPerformed(ActionEvent ae)
    {
      Object obj = ae.getSource();
      String message = ae.getActionCommand();

      if (obj instanceof JButton )
        if (ae.getActionCommand().equals("Start"))
        {
          flag = true;
        }
        if (message.equals("Stop"))
        {
          flag = false;
        }
      
    }
  }

  //For the ScrollBars
  class AdjustmentHandler implements AdjustmentListener
  {
    public void adjustmentValueChanged(AdjustmentEvent e)
    {
      JScrollBar sb = (JScrollBar) e.getSource();
      String str = sb.getName();
      int value = sb.getValue();

      if (str.equals("sb0"))
      {
        if(value < 10)
        {
          jl[0].setText(scroll_name[0] + "0" + value);
        }
        else
        {
          jl[0].setText(scroll_name[0] + value);
        }
        if(x_inc >= 0)
        {
          x_inc = value;
        }
        else
        {
          x_inc = -value;
        }
      }
      else if (str.equals("sb1"))
      {
        if(value < 10)
        {
          jl[1].setText(scroll_name[1] + "0" + value);
        }
        else
        {
          jl[1].setText(scroll_name[1] + value);
        }
        if(y_inc >= 0)
        {
          y_inc = value;
        }
        else
        {
          y_inc = -value;
        }
      }
      else if (str.equals("sb2"))
      {
        if(value < 10)
        {
          jl[2].setText(scroll_name[2] + "0" + value);
        }
        else
        {
          jl[2].setText(scroll_name[2] + value);
        }
        x_size = value;
        if(flag)
        {
          bp.repaint();
        }
      }
      else if (str.equals("sb3"))
      {
        if(value < 10)
        {
          jl[3].setText(scroll_name[3] + "0" + value);
        }
        else
        {
          jl[3].setText(scroll_name[3] + value);
        }
        y_size = value;
        if(!flag)
        {
          bp.repaint();
        }
      }
      else if (str.equals("sb4"))
      {
        if(value < 10)
        {
          jl[4].setText(scroll_name[4] + "0" + value);
        }
        else
        {
          jl[4].setText(scroll_name[4] + value);
        }
        speed = value;
      }
    }
  }

  class BallPanel extends JPanel
  {
      BallPanel()
      {
        x_pos = 5;
        y_pos = 5;
        
      }

      public void paintComponent(Graphics g)
      {
          super.paintComponent(g);
          g.setColor(Color.WHITE);
          g.fillRect(0, 0, bounds.width, bounds.height);
          g.setColor(Color.blue);
          g.fillOval(x_pos, y_pos, x_size, y_size);

      }
    }

    public void ballMovement()
    {
      if ( (x_pos < 5) || (x_pos > (bounds.width - x_size)))
      {
        x_inc = -x_inc;
      }

      if ( (y_pos < 5) || (y_pos > (bounds.height - y_size)))
      {
        y_inc = -y_inc;
      }

      x_pos += x_inc;
      y_pos += y_inc;
      bp.repaint();

      try
      {
        Thread.sleep(100 - speed);
      }
      catch (InterruptedException ie)
      {
        ie.printStackTrace();
      }
    }


  public static void main(String[] args)
  {
    ButtonBounce buttonbounce = new ButtonBounce();
  }
}