
//Taylor Heatherly

package program7;
import javax.swing.*;
import javax.swing.Timer;

import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.util.*;

public class SpaceInvaders extends JFrame 
{
	//images
	private Image cannon = Toolkit.getDefaultToolkit().getImage("program7/cannon1.png");
	private Image background=Toolkit.getDefaultToolkit().getImage("program7/bg2.png");
	private Image single_invader=Toolkit.getDefaultToolkit().getImage("program7/target.png");
	private Image single_ball=Toolkit.getDefaultToolkit().getImage("program7/cannonBall.png");
	Image[] invaders=new Image[10];
	public int Score=0;
	JLabel scoreLabel = new JLabel("Score: " + Score);
	JLabel loselabel= new JLabel("You lost Press down key to try again");
	JLabel winlabel = new JLabel("YOU WIN!!   Press down key to restart");
	

	Font f = new Font("Serif", Font.BOLD, 18);
	
	Image balls;
	private PPanel pp;
	private int x_pic = 0;
	private int y_pic = 400;
	private boolean cannon_touched = false;
	private int x_offset;
	private int y_offset; 
	private int[] randomX=new int[10];
	private int[] randomY=new int[10];
	public int initialized=0;
	public int started=0;
	public int dead[]=new int[10];
	public int ball;
	public int ballx;
	public int bally;
	public int balli=0;
	public int time=0;
	public int fired=0;
	public int shotsfired=0;
	int alienskilled=0;
	boolean win=false;
	boolean lose=false;
	boolean reset=false;
	public boolean timerboolean=false;
	public java.util.Timer timer;
	public boolean rerun=false;
	JLabel display=new JLabel("Down to Start");
	public Timer clock;
	public int secs = 0;
	public int mins = 0;
	public int hrs = 0;
	private DecimalFormat dFormat = new DecimalFormat("00");



	public SpaceInvaders(boolean reset) 
	{

		super("SpaceInvaders");

		pp= new PPanel(reset);
		pp.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		this.add(pp,BorderLayout.WEST);
		this.setSize(640, 480);

		this.setVisible(true);
	}

	public static void main(String[] args) 
	{ boolean reset=false;
	new SpaceInvaders(reset);
	}
	public class PPanel extends JPanel implements ActionListener
	{
		public PPanel(boolean reset)
		{
			super();
			setPreferredSize(new Dimension(640,480));
			this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			this.addMouseMotionListener(new MouseHandler());
			this.addMouseListener(new MouseClickedHandler());
			this.addKeyListener(new KeyHandler());
			this.setFocusable(true);
			




			scoreLabel.setFont(scoreLabel.getFont().deriveFont(14.0f));
			add(scoreLabel);
			scoreLabel.setLocation(540+40,320);

			scoreLabel.setFont(scoreLabel.getFont().deriveFont(14.0f));
			scoreLabel.setPreferredSize(new Dimension(100,100));


			clock = new Timer(10, this);
			if (reset==true){
				clock.start();
				timer = new java.util.Timer();
				TimerFired tf = new TimerFired();
				timer.scheduleAtFixedRate( tf, 0, 10 );

			}




		}	

		@Override

		public void actionPerformed(ActionEvent e)
		{

			if (e.getSource() == clock)
			{
				secs++;
			}

			if (secs == 60)
			{
				mins++;
				secs = 0;
			}

			if (mins == 60)
			{
				hrs++;
				mins = 0;
				secs = 0;
			}

			if (hrs == 24)
			{
				hrs = 0;
				mins = 0;
				secs = 0;
			}
			display.setText(
					dFormat.format(hrs) + ":" + 
							dFormat.format(mins) + ":" + 
							dFormat.format(secs));
		}

		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			g.drawImage(background,0,0,640,480,this);
			g.setFont(f);
			g.drawString("Time: " + display.getText(), 100, 60);
			g.drawString("Shots Fired:  " + shotsfired, 100, 120);



			if (rerun==false){


				for (int i=0; i<10;i++)
				{
					Random randomGenerator = new Random();
					randomX[i]=showRandomInteger(40,590,randomGenerator);
					randomY[i]=showRandomInteger(50,150,randomGenerator);
				}
			}
			rerun=true;

			if (fired==1)
			{

				balls=single_ball;
				g.drawImage(balls,ballx,bally=bally--,10,10,this);
				bally=bally-2;
				if (bally<0)
				{
					shotsfired++;
					fired=0;
				}
			}
			for (int i =0; i < 10; ++i)
			{
				if((ballx>=randomX[i]-10)&&(ballx<=randomX[i]+30)&&(bally<=randomY[i]+30)&&(bally>=randomY[i]-10)&&(dead[i]==0))
				{
					shotsfired++;
					fired=0;
					dead[i]=1;
					alienskilled++;
					someoneScored();

				}
				if (randomY[i]>=400){
					g.drawString("You lost Press down key to try again",180, 20);
					youlose();
				}
				if (dead[i]==0)
				{
					invaders[i] = single_invader;
					g.drawImage(invaders[i],randomX[i],randomY[i],30,30,this);
				}
			}

			g.drawImage(cannon, x_pic, y_pic, this);

		}
		

		private void someoneScored() {

			Score++;

			scoreLabel.setText("Score: " + Score);

			if (Score==10){
				clock.stop();
				youwin();
			}

		}
		public void youwin(){
			add(winlabel);
			remove(scoreLabel);
			win=true;

		}
		public void youlose(){
			clock.stop();
			remove(scoreLabel);
			add(loselabel);
			lose=true;
			
		
		}

	}

	class MouseClickedHandler extends MouseAdapter
	{
		public void mousePressed(MouseEvent me)
		{
			if ( (me.getX() > x_pic) && (me.getX() < x_pic + 100) && (me.getY() > y_pic) && (me.getY() < y_pic + 100))
			{
				cannon_touched = true;
				x_offset = me.getX() - x_pic;
				y_offset = me.getY() - y_pic;
			}
			else
				cannon_touched = false;
		}
	}
	class MouseHandler extends MouseMotionAdapter
	{

		public void mouseDragged(MouseEvent e)
		{
			if ((cannon_touched))
			{
				x_pic = e.getX() - x_offset;
				if(x_pic>580)
					x_pic=580;
				else if(x_pic<=0)
					x_pic=0;
			}
			pp.repaint();
		}
	}
	private static int showRandomInteger(int aStart, int aEnd, Random aRandom)
	{
		if (aStart > aEnd) 
			throw new IllegalArgumentException("Start cannot exceed End.");
		long range = (long)aEnd - (long)aStart + 1;
		long fraction = (long)(range * aRandom.nextDouble());
		int randomNumber = (int)(fraction + aStart);
		return randomNumber;
	}

	public class TimerFired extends TimerTask
	{
		
		int idk=0;
		public void run()
		{
			
			idk++;
			for (int i =0; i < 10; ++i)
			{
				if ((randomY[i]>=30)&&(idk%10==0))
					randomY[i]++;
				

			}
			
			repaint();
		}
	}
	class KeyHandler implements KeyListener
	{
		public void keyPressed(KeyEvent e) 
		{

			if (e.getKeyCode() == KeyEvent.VK_DOWN)
			{

				clock.start();
				timer = new java.util.Timer();
				TimerFired tf = new TimerFired();
				timer.scheduleAtFixedRate( tf, 0, 10 );
				pp.repaint();
				if (win==true || lose==true)
					reset();
			}
			else if (e.getKeyCode() == KeyEvent.VK_UP)
			{

				if (fired==0)
				{
					ballx=x_pic+15;
					bally=400;
					fired=1;
				}
				pp.repaint();
			}
			else if (e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				x_pic=x_pic+5;
				if(x_pic>580)
					x_pic=580;
				pp.repaint();
			}
			else if (e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				x_pic=x_pic-5;
				if(x_pic<=0)
					x_pic=0;
				pp.repaint();
			}


		}

		public void keyReleased(KeyEvent e) 
		{

		}
		public void keyTyped(KeyEvent e) 
		{

		}


		public void reset(){
			reset=true;
			new SpaceInvaders(reset);

		}

	}
}